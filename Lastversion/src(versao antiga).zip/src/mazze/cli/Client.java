package mazze.cli;

import java.util.Scanner;

import maze.logic.*;

public class Client 
{
	public static void imprimeHeroi()
	{
		if (Heroi.vivo)
			if(Heroi.armado)
				System.out.print('A');
			else if(Heroi.protegido)
				System.out.print('P');
			else
				System.out.print('H');
		else System.out.print('M');
	}
	
	public static void imprimeEspada()
	{
		System.out.print('E');
	}
	
	public static void imprimeDragao(Dragao dragao, int espaday, int espadax)
	{
		if(dragao.vivo)
			if (dragao.posicao.x == espadax && dragao.posicao.y == espaday)
				System.out.print('F');
			else if(dragao.dormir)
				System.out.print('d');
			else System.out.print('D');
	}
	
	public static void imprimeEscudo()
	{
		System.out.print('S');
	}
	
	public static void imprimeDardo()
	{
		System.out.print('�');
	}
	
	public static void desenhaLabirinto() 
	{
		for (int height = 0; height < Jogo.dimensaoLabirinto; height++) 
		{
			for (int width = 0; width < Jogo.dimensaoLabirinto; width++)
			{
				int drake = Jogo.verificaDragao(width, height);
				int dardinho = Jogo.verificaDardo(width, height);

				if (height == Heroi.cor.y && width == Heroi.cor.x )
					imprimeHeroi();
				else if (drake != -1)
					imprimeDragao((Jogo.dragoes.get(drake)), Espada.posicao.x, Espada.posicao.y);
				else if(dardinho != -1)
					imprimeDardo();
				else if (height == Espada.posicao.y && width == Espada.posicao.x && !Espada.recolhida)
					imprimeEspada();
				else if (height == Escudo.posicao.y && width == Escudo.posicao.x && !Escudo.recolhida)
					imprimeEscudo();
				else
					Labirinto.imprimeTabuleiro(height, width);

				System.out.print(' ');

			}

			System.out.print('\n');
		}

		System.out.println("w - Mover para cima");
		System.out.println("a - Mover para a esquerda");
		System.out.println("s - Mover para baixo");
		System.out.println("d - Mover para a direita");

		if(Heroi.numDardos > 0)
			System.out.println("e - Disparar dardos");

	}
	
	public static boolean mensagemInicial()
	{
		Jogo.dimensaoLabirinto = 0;
		
		@SuppressWarnings("resource")
		Scanner in2 = new Scanner(System.in);
		

		System.out.println("Deseja criar um labirinto? ^^ ");
		System.out.println(" y - sim ");
		System.out.println(" n - n�o");
		char res = in2.next().charAt(0);

		in2.reset();
		System.out.println("\nComo pretende que o Dragao se movimente:");
		System.out.println(" 1 - Dragao parado ");
		System.out.println(" 2 - Dragao com movimento aleatorio ");
		System.out.println(" 3 - Dragao com movimento aleatorio e possibilidade de adormecer");
		int temp = in2.nextInt();

		
		if (temp == 2)
			Jogo.dragonMoves = 5;
		else if (temp == 3)
			Jogo.dragonMoves = 6;

		
		in2.reset();
		if(res == 'y') 
		{
			System.out.println("\nQuantos dragoes deseja enfrentar? Por defini��o, o jogo ser� iniciado com um Drag�o.");
			temp = in2.nextInt();
			
			Jogo.numDragoes = temp;

			while(Jogo.dimensaoLabirinto == 0)
			{
				System.out.println("\nInsira a dimensao do labirinto (NxN) pretendida. Aconselha-se uma dimensao igual ou superior a 7!");
				System.out.println("\nBoa Sorte Sweet! ^^ ");
				@SuppressWarnings("resource")
				Scanner in = new Scanner(System.in);
				int n = in.nextInt();

				if (n >= 7)
					Jogo.dimensaoLabirinto = n;
			}
			return true;
		}
		else  
		{
			System.out.println("\n\nBoa Sorte Sweet! ^^ ");
			return false;
		}
		
	}
	
	public static void mensagemFinal()
	{
		if (Heroi.vivo)
			if (Jogo.dragoes.size() == 0)
				System.out.println("Terminou o jogo! Boa! Experimenta lutar tambem contra o dragao!");
			else System.out.println("Terminou o jogo abatendo tambem o dragao!!! Parabens! :)");
		else System.out.println("O Heroi foi abatido pelo dragao :( ...");
	}


	
	public static char direcaoDardo()
	{
		System.out.println("w - Disparar para cima");
		System.out.println("a - Disparar para a esquerda");
		System.out.println("s - Disparar para baixo");
		System.out.println("d - Disparar para a direita");
		System.out.println("e - Cancelar");

		return Jogo.caraterPremido();
	}
}
