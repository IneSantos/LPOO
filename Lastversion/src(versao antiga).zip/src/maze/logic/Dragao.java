package maze.logic;

import java.io.Serializable;

public class Dragao implements Serializable{

	public Coordenada posicao;
	public int niteracoes;

	public boolean vivo;
	public boolean dormir;

	public Dragao(int x, int y)
	{
		this.posicao = new Coordenada(x, y);
		this.vivo = true;
		this.dormir = false;
		this.niteracoes = 0;
	}

	//SO TESTA PARA UM DRAGAO, RETORNA 1,2,3,4 DE ACORDO COM A POSICAO DO HEROI EM RELACAO AO DRAGAO
	public int linhaMiraDragao()
	{

		if(posicao.x == Heroi.cor.x && Heroi.cor.y < posicao.y && Math.abs(posicao.y-Heroi.cor.y) <= 3 )
			return 1; //cima
		else if(posicao.x == Heroi.cor.x && Heroi.cor.y > posicao.y && Math.abs(posicao.y-Heroi.cor.y)<=3  )
			return 2; // baixo
		else if(posicao.y == Heroi.cor.y && Heroi.cor.x < posicao.x  && Math.abs(posicao.x-Heroi.cor.x)<=3 )
			return 3; //esquerda
		else if(posicao.y == Heroi.cor.y && Heroi.cor.x > posicao.x && Math.abs(posicao.x-Heroi.cor.x)<=3 )
			return 4; //direita
		else			
			return -1;
	}
	
	public boolean verificaWall()
	{
		int temp = linhaMiraDragao();
		
		for(int i =0; i <= 3 ; ++i)
		{
			if(temp == 1)
			{
				if(Labirinto.labirinto[posicao.y - i][posicao.x] == 'X')
				return true;
			}
			else if(temp == 2)
			{
				if(Labirinto.labirinto[posicao.y + i][posicao.x] == 'X')
					return true;
			}
			else if(temp == 3)
			{
				if(Labirinto.labirinto[posicao.y][posicao.x-i] == 'X')
					return true;
			}
			else if(temp == 2)
			{
				if(Labirinto.labirinto[posicao.y][posicao.x+i] == 'X')
					return true;
			}
		}
		
		return false;
	}

}
