package maze.logic;

import java.io.Serializable;
import java.util.Random;

import maze.logic.Coordenada;
import maze.logic.Labirinto;

public class Escudo implements Serializable{

	public static Coordenada posicao;
	public static boolean recolhida;
	
	
	public Escudo(int x, int y){
		Escudo.posicao =  new Coordenada(x,y);
		recolhida = false;
	}
	

	
	public static void deployShield()
	{
		Random randomGen = new Random ();
		boolean definido = false;

		while(!definido)
		{
			int x = randomGen.nextInt(Jogo.dimensaoLabirinto - 2) + 1;
			int y = randomGen.nextInt(Jogo.dimensaoLabirinto - 2) + 1;

			if((x != Jogo.heroi.cor.x || y != Jogo.heroi.cor.y) && Labirinto.espacoLivreHeroi(y, x) && (x != Espada.posicao.x || y != Espada.posicao.y) && Jogo.verificaDardo(x, y) == -1)
			{
				posicao = new Coordenada(x,y);
				definido = true;
			}
		}
	}
}
