package maze.logic;

public class Coordenada
{
	@Override
	public boolean equals(Object o) 
	{
		return (o != null) && (o instanceof Coordenada) && ((Coordenada)o).x == x && ((Coordenada)o).y == y;
	}

	public int x;
	public int y;
	
	public Coordenada (int first, int second) 
	{ 
		this.x = first;
		this.y = second;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}
	
}
