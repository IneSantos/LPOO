package maze.logic;

import java.io.Serializable;
import java.util.Random;

import maze.logic.*;

public class Heroi implements Serializable {

	public static Coordenada cor;
	public static boolean armado;
	public static boolean protegido;
	public static boolean vivo;
	public static boolean fireDanger;
	public static int numDardos;


	public Heroi()
	{
		numDardos = 0;
		armado = false;
		vivo = true;
		protegido = false;
		fireDanger = false;
	}

	
	public static void deployHero()
	{
		new Heroi();
		
		Random randomGen = new Random ();
		boolean definido = false;

		if (Labirinto.Saida.x == 0)
		{
			while(!definido)
			{
				int y = randomGen.nextInt(Jogo.dimensaoLabirinto-2) + 1;

				if(Labirinto.labirinto[y][Jogo.dimensaoLabirinto - 2] == ' ')
				{
					definido = true;
					cor = new Coordenada(Jogo.dimensaoLabirinto - 2, y);
				}
			}
		}
		else if (Labirinto.Saida.x == Jogo.dimensaoLabirinto - 1)
		{
			while(!definido)
			{
				int y = randomGen.nextInt(Jogo.dimensaoLabirinto-2) + 1;

				if(Labirinto.labirinto[y][1] == ' ')
				{
					definido = true;
					cor = new Coordenada(1, y);
				}
			}
		}
		else if (Labirinto.Saida.y == 0)
		{
			while(!definido)
			{
				int x = randomGen.nextInt(Jogo.dimensaoLabirinto-2) + 1;

				if(Labirinto.labirinto[Jogo.dimensaoLabirinto - 2][x] == ' ')
				{
					definido = true;
					cor = new Coordenada(x, Jogo.dimensaoLabirinto - 2);
				}
			}
		}
		else if (Labirinto.Saida.y == Jogo.dimensaoLabirinto - 1)
		{
			while(!definido)
			{
				int x = randomGen.nextInt(Jogo.dimensaoLabirinto-2) + 1;

				if(Labirinto.labirinto[1][x] == ' ')
				{
					definido = true;
					cor = new Coordenada(x, 1);
				}
			}
		}
	}


	public static void disparaDardo(char dir)
	{
		if(numDardos == 0)
			return;
		
		if(dir == 'w')
		{
			for(int i = 0; i < Jogo.dragoes.size(); ++i)
			{
				if(Jogo.dragoes.get(i).posicao.x == cor.x && Jogo.dragoes.get(i).posicao.y < cor.y && Labirinto.caminhoLivre(Jogo.dragoes.get(i).posicao, Heroi.cor))
				{
					Jogo.dragoes.get(i).vivo = false;
					break;
				}	
			}
		}
		else if(dir == 's')
		{	
			for(int i = 0; i < Jogo.dragoes.size(); ++i)
			{
				if(Jogo.dragoes.get(i).posicao.x == cor.x && Jogo.dragoes.get(i).posicao.y > cor.y && Labirinto.caminhoLivre(Jogo.dragoes.get(i).posicao, Heroi.cor))
				{
					Jogo.dragoes.get(i).vivo = false;
					break;
				}			
			}
		} 
		else if(dir == 'a')
		{
			for(int i = 0; i < Jogo.dragoes.size(); ++i)
			{
				if(Jogo.dragoes.get(i).posicao.y == cor.y && Jogo.dragoes.get(i).posicao.x < cor.x && Labirinto.caminhoLivre(Jogo.dragoes.get(i).posicao, Heroi.cor))
				{
					Jogo.dragoes.get(i).vivo = false;
					break;
				}
			}
		} 
		else if(dir == 'd')
		{	
			for(int i = 0; i < Jogo.dragoes.size(); ++i)
			{
				if(Jogo.dragoes.get(i).posicao.y == cor.y && Jogo.dragoes.get(i).posicao.x > cor.x && Labirinto.caminhoLivre(Jogo.dragoes.get(i).posicao, Heroi.cor))
				{
					Jogo.dragoes.get(i).vivo = false;
					break;
				}			
			}
		}

		numDardos--;
	}
	
}
