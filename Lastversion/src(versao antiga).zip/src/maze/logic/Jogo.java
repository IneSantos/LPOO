package maze.logic;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.*;

import mazze.cli.Client;


public class Jogo implements Serializable
{
	public static int dimensaoLabirinto;
	public static int dragonMoves;
	public static int numDragoes;

	public static Labirinto labirinto;
	public static Heroi heroi;
	public static List<Dragao> dragoes;
	public static List<Dardo> dardos;
	public static Espada espada;
	public static Escudo escudo;

	public static boolean termina = false;
	public static Jogo obj = new Jogo();
	 


	public static void main(String[] args) 
	{
		File file = new File("Jogo.ser");
	    ObjectOutputStream os = null;

	    try {
	     os = new ObjectOutputStream(new FileOutputStream(file));
	     os.writeObject(obj);
	    }
	    catch (IOException except) { }
	    finally { if (os != null)
	     try {
	      os.close();
	     } catch (IOException e1) {
	      e1.printStackTrace();
	     }     }
	    
	    
	    
		if(Client.mensagemInicial())
			generateLabirinto();
		else standardLabirinto();

		Client.desenhaLabirinto();
		
		char tecla; 
		
		while (!termina)
		{
			tecla = caraterPremido();

			verificaMovimentoHeroi(tecla);
			
			moveDragoes();
			verificaHeroiDragao();

			if (!Heroi.vivo)
				termina = true;

			Client.desenhaLabirinto();

		}

		Client.mensagemFinal();

	}

	public static void standardLabirinto()
	{
		dragoes = new ArrayList<Dragao>();
		dardos = new ArrayList<Dardo>();
		
		dimensaoLabirinto = 10;

		heroi = new Heroi();
		Heroi.cor = new Coordenada(1,1);

		Espada.posicao = new Coordenada(1, 8);

		Dragao d = new Dragao(1, 3);
		dragoes.add(d);

		Labirinto.Saida = new Coordenada(9, 5);
		
		escudo = new Escudo(0, 0);
		Escudo.recolhida = true;
	}

	public static void generateLabirinto()
	{
		dragoes = new ArrayList<Dragao>();
		dardos = new ArrayList<Dardo>();
		
		Labirinto.criaLabirinto(dimensaoLabirinto);

		Heroi.deployHero();

		deployDragons();

		deployDarts();

		Espada.deploySword();

		Escudo.deployShield();
	}
	
/*
	public static int verificaFireBall(int x, int y, char dir)
	{

		for(int i = 0; i < fireballs.size(); ++i)
		{
			if(dir == 'w'){
				if(fireballs.get(i).posicao.x == x &&  y < fireballs.get(i).posicao.y && fireballs.get(i).posicao.y + 3 <= y ){
					return i;
				}
			}else if(dir == 's'){
				if(fireballs.get(i).posicao.x == x &&  y > fireballs.get(i).posicao.y && fireballs.get(i).posicao.y + 3 <= y){
					return i;
				}				
			}else if(dir == 'a'){
				if(fireballs.get(i).posicao.y == y &&  x < fireballs.get(i).posicao.x && fireballs.get(i).posicao.x + 3 <= x){
					return i;
				}
			}else if(dir == 'd'){
				if(fireballs.get(i).posicao.y == y &&  x > fireballs.get(i).posicao.x && fireballs.get(i).posicao.x + 3 <= x){
					return i;
				}				
			}
		}

		return -1;

	}


	public static boolean verificaFireballHeroi(){
		int vfb = 0;
		if(vfb != -1 )
			return true;
		else return false;
	}
*/
	
	public static int verificaDragao(int x, int y)
	{

		for(int i = 0; i < dragoes.size(); ++i)
		{
			if(dragoes.get(i).posicao.x == x && dragoes.get(i).posicao.y == y)
				return i;
		}

		return -1;

	}

	public static int verificaDardo(int x, int y)
	{

		for(int i=0; i < dardos.size(); ++i)
		{
			if(dardos.get(i).posicao.x == x && dardos.get(i).posicao.y == y)
				return i;
		}

		return -1;
	}

	public static void deployDragons()
	{
		Random randomGen = new Random ();
		boolean definido;
		int temp = numDragoes;

		while (numDragoes > 0)
		{
			definido = false;
			while(!definido)
			{
				int x = randomGen.nextInt(dimensaoLabirinto - 2) + 1;
				int y = randomGen.nextInt(dimensaoLabirinto - 2) + 1;

				if(x != Heroi.cor.x && y != Heroi.cor.y && Labirinto.espacoLivreHeroi(y, x) && verificaDragao(x,y) == -1)
				{
					dragoes.add(new Dragao(x, y));

					definido = true;
				}
			}

			numDragoes--;
		}

		numDragoes = temp;
	}

	public static void deployDarts()
	{
		Random randomGen = new Random ();
		int numDarts = randomGen.nextInt(3) + numDragoes;

		boolean definido;

		while (numDarts > 0)
		{
			definido = false;
			while(!definido)
			{
				int x = randomGen.nextInt(dimensaoLabirinto - 2) + 1;
				int y = randomGen.nextInt(dimensaoLabirinto - 2) + 1;

				if(x != Heroi.cor.x && y != Heroi.cor.y && labirinto.espacoLivreHeroi(y, x) && verificaDragao(x,y) == -1 && verificaDardo(x,y) == -1)
				{
					dardos.add(new Dardo(x, y));

					definido = true;
				}
			}

			numDarts--;
		}
	}

	public static char caraterPremido() 
	{
		@SuppressWarnings("resource")
		Scanner s = new Scanner(System.in);
		char x = s.next().charAt(0);

		return x;
	}

	public static void moveHeroi(char tecla)
	{

		if(tecla == 'w')
			Heroi.cor.y--;
		else if(tecla == 's')
			Heroi.cor.y++;
		else if(tecla == 'a')
			Heroi.cor.x --;
		else if(tecla == 'd')
			Heroi.cor.x ++;	


		int dardinho = verificaDardo(Heroi.cor.x ,Heroi.cor.y); 

		if (Heroi.cor.equals(Espada.posicao) && !Espada.recolhida)
		{
			Heroi.armado = true;
			Espada.recolhida = true;
		}

		if (Heroi.cor.equals(Escudo.posicao) && !Escudo.recolhida)
		{
			Heroi.protegido = true;
			Escudo.recolhida = true;
		}

		if(dardinho != -1)
		{
			Heroi.numDardos++;
			dardos.remove(dardinho);
		}

		if (Heroi.cor.equals(Labirinto.Saida))
		{
			if (!Heroi.armado)
			{
				if(tecla == 'w')
					Heroi.cor.y++;
				else if(tecla == 's')
					Heroi.cor.y--;
				else if(tecla == 'a')
					Heroi.cor.x ++;
				else if(tecla == 'd')
					Heroi.cor.x --;	
			}
			else termina = true;
		}
	}

	public static void moveDragoes()
	{
		for(int i = 0; i < dragoes.size(); ++i)
		{
			if(dragoes.get(i).vivo)
				moveDragao(dragoes.get(i));
		}

	}

	public static void moveDragao(Dragao dragao)
	{
		Random randomGen = new Random ();

		if(!dragao.dormir)
		{
			boolean validAction = false;
			
			while(!validAction)
			{
				int orientation = randomGen.nextInt(dragonMoves);
				
				if(orientation == 0 && Labirinto.espacoLivreDragao(dragao.posicao.y - 1, dragao.posicao.x) )
				{
					dragao.posicao.y--;
					validAction = true;
				}
				else if(orientation == 1 && Labirinto.espacoLivreDragao(dragao.posicao.y + 1, dragao.posicao.x))
				{
					dragao.posicao.y++;
					validAction = true;
				}
				else if(orientation == 2 && Labirinto.espacoLivreDragao(dragao.posicao.y, dragao.posicao.x - 1))
				{
					dragao.posicao.x--;
					validAction = true;
				}
				else if(orientation == 3 && Labirinto.espacoLivreDragao(dragao.posicao.y, dragao.posicao.x + 1))
				{
					dragao.posicao.x++;
					validAction = true;
				}
				else if (orientation == 4)
				{
					validAction = true;
				}
				else if (orientation == 5)
				{
					dragao.dormir = true;
					dragao.niteracoes = 3;
					validAction = true;
				}
			}
			
			int sight = dragao.linhaMiraDragao();
			int shootingProb = randomGen.nextInt(4);
			
			if(sight != -1 && shootingProb != 0 && !dragao.dormir)
				if(!dragao.verificaWall() && !Heroi.protegido)
				{
					Heroi.vivo = false;
					Jogo.termina = true;
				}
		}
		else if(dragao.niteracoes == 0)
			dragao.dormir = false;
		else dragao.niteracoes--;
		

			
		
	}

	public static void verificaHeroiDragao()
	{
		for(int i = 0; i < dragoes.size(); ++i)
		{
			int k = dragaoAdjacente(i);

			if(k != -1)
			{

				if(Heroi.armado)
					Jogo.dragoes.get(k).vivo = false;
				else if(!dragoes.get(k).dormir)
				{
					Heroi.vivo = false;
					termina = true;
				}
			}
		}
	}

	public static void verificaMovimentoHeroi(char tecla) 
	{

		if (tecla == 'w') 
		{
			if(Labirinto.espacoLivreHeroi(Heroi.cor.y - 1, Heroi.cor.x ))
				moveHeroi(tecla);
		} 
		else if (tecla == 's') 
		{
			if(Labirinto.espacoLivreHeroi(Heroi.cor.y + 1, Heroi.cor.x ))
				moveHeroi(tecla);
		} 
		else if (tecla == 'a') 
		{
			if(Labirinto.espacoLivreHeroi(Heroi.cor.y, Heroi.cor.x - 1))
				moveHeroi(tecla);
		} 
		else if (tecla == 'd') 
		{
			if(Labirinto.espacoLivreHeroi(Heroi.cor.y, Heroi.cor.x + 1))
				moveHeroi(tecla);
		}
		else if (tecla == 'e')
		{
			char direcao = Client.direcaoDardo();
			if(direcao == 'w' || direcao == 'a' || direcao == 's' || direcao == 'd' || direcao == 'e')
				Heroi.disparaDardo(direcao);
			
		}
	}

	public static int dragaoAdjacente(int i)
	{

		if(dragoes.get(i).posicao.y + 1 == heroi.cor.y && dragoes.get(i).posicao.x == heroi.cor.x || dragoes.get(i).posicao.y - 1 == heroi.cor.y && dragoes.get(i).posicao.x == heroi.cor.x )
			return i;
		else if (dragoes.get(i).posicao.y == heroi.cor.y && dragoes.get(i).posicao.x + 1 == heroi.cor.x || dragoes.get(i).posicao.y == heroi.cor.y && dragoes.get(i).posicao.x - 1 == heroi.cor.x )
			return i;
		else if (dragoes.get(i).posicao.x == heroi.cor.x && dragoes.get(i).posicao.y == heroi.cor.y)
			return i;
		else return -1;
	}

}
