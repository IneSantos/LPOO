package maze.logic;

import java.io.Serializable;

import maze.logic.Coordenada;

public class Dardo implements Serializable{

	public Coordenada posicao;

	public Dardo(int x, int y){
		this.posicao =  new Coordenada(x,y);
	}



	
}
