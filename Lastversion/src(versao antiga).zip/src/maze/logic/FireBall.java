package maze.logic;

import java.io.Serializable;

import maze.logic.Coordenada;

public class FireBall implements Serializable{
	
	public Coordenada posicao;
	public int distancia;
	public char dir;
	
	public FireBall(int x, int y, char direcao){
		posicao = new Coordenada(x,y);
		distancia = 3;
		dir = direcao;
	}
	
	public void moveFireBall(){
		
		if(dir == 'w'){
			posicao.y--;
		}
		else if(dir == 's'){
			posicao.y++;
		}
		else if(dir == 'a'){
			posicao.x--;
		}
		else if(dir == 'd'){
			posicao.x++;
		}
		
		distancia--;
	}

	public void printFireBall(){
		System.out.print('*');
	}
	
	
	
	
}
