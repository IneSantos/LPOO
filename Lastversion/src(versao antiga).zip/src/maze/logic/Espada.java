package maze.logic;

import java.io.Serializable;
import java.util.Random;


public class Espada implements Serializable
{
	public static Coordenada posicao;
	public static boolean recolhida = false;
	
	
	public static void deploySword()
	{
		Random randomGen = new Random ();
		boolean definido = false;

		while(!definido)
		{
			int x = randomGen.nextInt(Jogo.dimensaoLabirinto - 2) + 1;
			int y = randomGen.nextInt(Jogo.dimensaoLabirinto - 2) + 1;

			if((x != Heroi.cor.x || y != Heroi.cor.y) && Labirinto.espacoLivreHeroi(y, x))
			{
				posicao = new Coordenada(x, y);
				definido = true;
			}
		}
	}
}
