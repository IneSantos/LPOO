package maze.gui;

import java.awt.event.*;

public class Controls {
	public static int up ;
	public static int down;
	public static int left;
	public static int right;
	
	public static int shootUp;
	public static int shootDown;
	public static int shootLeft;
	public static int shootRight;

	
	public Controls(){
		 up = KeyEvent.VK_UP;
		 down = KeyEvent.VK_DOWN;
		 left = KeyEvent.VK_LEFT;
		 right = KeyEvent.VK_RIGHT;
			
		 shootUp = KeyEvent.VK_W;
		 shootDown = KeyEvent.VK_S;
		 shootLeft = KeyEvent.VK_A;
		 shootRight = KeyEvent.VK_D;
	}

}
