package maze.gui;


import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ButtonGroup;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


import maze.logic.*;


import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;

import java.awt.Font;

public class Settings extends JDialog implements ActionListener
{
	static int old_key;
	private static Settings dialog = new Settings();
	private final JPanel contentPanel = new JPanel();
	private JSpinner spinner = new JSpinner();
	JButton okButton = new JButton("OK");
	JButton cancelButton = new JButton("Cancel");

	
	protected JButton btnUp = new JButton();
	

	JButton btnDown = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().down));
	JButton btnLeft = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().left));
	JButton btnRight = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().right));
	
	
	JButton button = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().shootUp));
	JButton button_1 = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().shootDown));
	JButton button_2 = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().shootLeft));
	JButton button_3 = new JButton(KeyEvent.getKeyText(StartMazze.getCtrls().shootRight));
	
	
	public static Settings getDialog() {
		return dialog;
	}

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		try {
//			
//			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
//			dialog.setVisible(true);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

	/**
	 * Create the dialog.
	 */
	public Settings() {
		ButtonGroup group = new ButtonGroup();
		ButtonGroup btnKey = new ButtonGroup();
		setBounds(100, 100, 450, 588);
		getContentPane().setLayout(null);
		contentPanel.setBounds(0, 0, 434, 549);
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel);
		contentPanel.setLayout(null);
		{
			JLabel lblDesejaCriarUm = new JLabel("Deseja criar um labirinto?");
			lblDesejaCriarUm.setBounds(56, 100, 149, 26);
			contentPanel.add(lblDesejaCriarUm);
		}
		
		JRadioButton rdbtnYes = new JRadioButton("SIM\r\n", false);
		rdbtnYes.setBounds(237, 102, 55, 23);
		contentPanel.add(rdbtnYes);
		group.add(rdbtnYes);
		rdbtnYes.addActionListener(new Yes_Settings());
		{
			JRadioButton rdbtnNo = new JRadioButton("N\u00C3O\r\n",true);
			rdbtnNo.setBounds(312, 102, 54, 23);
			contentPanel.add(rdbtnNo);
			group.add(rdbtnNo);
			rdbtnNo.addActionListener(new NO_Settings());
		}
		{
			JLabel lblNewLabel = new JLabel("Movimentos Dragao");
			lblNewLabel.setBounds(55, 152, 120, 26);
			contentPanel.add(lblNewLabel);
		}
		
		JComboBox comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Parado", "Aleat\u00F3rio", "Aleat\u00F3rio + Drag\u00E3o adormecer"}));
		comboBox.setSelectedIndex(0);
		comboBox.setBounds(185, 155, 181, 20);
		contentPanel.add(comboBox);
		comboBox.addActionListener(new ComboListener());
		{
			JLabel lblNDrages = new JLabel("N\u00BA Drag\u00F5es em jogo");
			lblNDrages.setBounds(55, 189, 120, 26);
			contentPanel.add(lblNDrages);
		}
		
		
		spinner.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(1)));
		spinner.setBounds(185, 192, 98, 20);
		contentPanel.add(spinner);
		
		
		JLabel lblNewLabel_1 = new JLabel("Alterar Comandos do jogo:");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(55, 238, 196, 31);
		contentPanel.add(lblNewLabel_1);
		
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setBounds(0, 503, 435, 35);
			contentPanel.add(buttonPane);
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			{
				
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
				okButton.addActionListener(this);
			}
			{
				
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
				
				btnUp.setFont(new Font("Tahoma", Font.PLAIN, 10));	
				btnUp.setBounds(245, 245, 98, 20);
				contentPanel.add(btnUp);
				btnUp.addActionListener(this);
				btnUp.setText(KeyEvent.getKeyText(ChangeKeys.old_key[0]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[0]));		
				
				
				btnDown.setFont(new Font("Tahoma", Font.PLAIN, 10));
				btnDown.setBounds(245, 265, 98, 20);
				contentPanel.add(btnDown);
				btnDown.addActionListener(this);
				btnDown.setText(KeyEvent.getKeyText(ChangeKeys.old_key[1]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[1]));
			
				btnLeft.setFont(new Font("Tahoma", Font.PLAIN, 10));
				btnLeft.addActionListener(this);
				btnLeft.setBounds(245, 285, 98, 20);
				contentPanel.add(btnLeft);
				btnLeft.setText(KeyEvent.getKeyText(ChangeKeys.old_key[2]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[2]));
				
				btnRight.setFont(new Font("Tahoma", Font.PLAIN, 10));
				btnRight.addActionListener(this);
				btnRight.setText(KeyEvent.getKeyText(ChangeKeys.old_key[3]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[3]));
				btnRight.setBounds(245, 305, 98, 20);
				contentPanel.add(btnRight);
				
				JLabel lblAlterarComandosDe = new JLabel("Alterar Comandos de disparo:");
				lblAlterarComandosDe.setHorizontalAlignment(SwingConstants.CENTER);
				lblAlterarComandosDe.setBounds(55, 365, 196, 31);
				contentPanel.add(lblAlterarComandosDe);
				
				button.addActionListener(this);
				button.setFont(new Font("Tahoma", Font.PLAIN, 10));
				button.setText(KeyEvent.getKeyText(ChangeKeys.old_key[4]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[4]));
				button.setBounds(245, 369, 65, 20);
				contentPanel.add(button);
				
				button_1.setFont(new Font("Tahoma", Font.PLAIN, 10));
				button_1.addActionListener(this);
				button_1.setText(KeyEvent.getKeyText(ChangeKeys.old_key[5]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[5]));
				button_1.setBounds(245, 390, 65, 20);
				contentPanel.add(button_1);
				
				
				button_2.setFont(new Font("Tahoma", Font.PLAIN, 10));
				button_2.setText(KeyEvent.getKeyText(ChangeKeys.old_key[6]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[6]));
				button_2.addActionListener(this);
				button_2.setBounds(245, 411, 65, 20);
				contentPanel.add(button_2);
				
				
				button_3.setFont(new Font("Tahoma", Font.PLAIN, 10));
				button_3.setText(KeyEvent.getKeyText(ChangeKeys.old_key[7]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[7]));
				button_3.addActionListener(this);
				button_3.setBounds(245, 432, 65, 20);
				contentPanel.add(button_3);
				cancelButton.addActionListener(this);
			}
		}
		
		{
			
		}
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource() == btnUp){

			ChangeKeys cenas = new ChangeKeys(this, "up");
			btnUp.updateUI();
			btnUp.setText(KeyEvent.getKeyText(ChangeKeys.old_key[0]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[0]));
			
			//btnUp.repaint();
		}
		else if(arg0.getSource() == btnDown){
			ChangeKeys cenas = new ChangeKeys(this, "down");
			btnDown.setText(KeyEvent.getKeyText(ChangeKeys.old_key[1]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[1]));
		}
		else if(arg0.getSource() == btnLeft){
			ChangeKeys cenas = new ChangeKeys(this, "left");
			btnLeft.setText(KeyEvent.getKeyText(ChangeKeys.old_key[2]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[2]));
		}
		else if(arg0.getSource() == btnRight){
			ChangeKeys cenas = new ChangeKeys(this, "right");
			btnRight.setText(KeyEvent.getKeyText(ChangeKeys.old_key[3]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[3]));
		}
		else
			if(arg0.getSource() == button){
				ChangeKeys cenas = new ChangeKeys(this, "shootup");
				button.setText(KeyEvent.getKeyText(ChangeKeys.old_key[4]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[4]));
			}
			else if(arg0.getSource() == button_1){
				ChangeKeys cenas = new ChangeKeys(this, "shootdown");
				button_1.setText(KeyEvent.getKeyText(ChangeKeys.old_key[5]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[5]));
			}
			else if(arg0.getSource() == button_2){
				ChangeKeys cenas = new ChangeKeys(this, "shootleft");
				button_2.setText(KeyEvent.getKeyText(ChangeKeys.old_key[6]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[6]));
			}
			else if(arg0.getSource() == button_3){
				ChangeKeys cenas = new ChangeKeys(this, "shootright");
				button_3.setText(KeyEvent.getKeyText(ChangeKeys.old_key[7]) + " - " + KeyEvent.getKeyText(ChangeKeys.new_key[7]));
			}
			else if(arg0.getSource() == okButton){
				Jogo.numDragoes = (int) this.spinner.getModel().getValue();
				dialog.setVisible(false);
				dialog.dispose();
			}else if(arg0.getSource() == cancelButton){
				Jogo.numDragoes = 1;
				Jogo.dimensaoLabirinto = 10;
				dialog.setVisible(false);
				dialog.dispose();
		}
	}

	
}
