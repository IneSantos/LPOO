package maze.gui;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import maze.logic.Heroi;

public class MyKeyListener implements KeyListener
{
	
	@Override
	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyChar() == 'w')
			Heroi.cor.y--;
		else if (e.getKeyChar() == 's')
			Heroi.cor.y++;
		else if (e.getKeyChar() == 'a')
			Heroi.cor.x--;
		else if (e.getKeyChar() == 'd')
			Heroi.cor.x++;
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}
