package maze.gui;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class SettingsListener extends Settings implements ActionListener{

	public SettingsListener(){
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Settings.getDialog().setVisible(true);
	}

	
}
