package maze.gui;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import maze.logic.Jogo;

public class Load {

	String filename;
	
	public Load(String filename){

		File file = new File(filename + ".ser"); 
		 ObjectInputStream in = null;

		    try {
		    	in = new ObjectInputStream(new FileInputStream(file));
		    	Jogo.obj = (Jogo) in.readObject();
		    	in.close();
		    	
		    }
		    catch (IOException except) {
		    	except.printStackTrace();
		         return;
		      }catch(ClassNotFoundException c)
		      {
		        c.printStackTrace();
		      }
		    
	}
	
	
}
