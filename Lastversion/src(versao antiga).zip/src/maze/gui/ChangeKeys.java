package maze.gui;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

@SuppressWarnings("serial")
public class ChangeKeys extends JDialog implements KeyListener{

	//up, down, left, right -- shootup, shootdown, shootleft, shootright

	public static int[] old_key = {KeyEvent.VK_UP,KeyEvent.VK_DOWN,KeyEvent.VK_LEFT,KeyEvent.VK_RIGHT,
		KeyEvent.VK_W,KeyEvent.VK_S,KeyEvent.VK_A,KeyEvent.VK_D};
	public static int[] new_key = {KeyEvent.VK_UP,KeyEvent.VK_DOWN,KeyEvent.VK_LEFT,KeyEvent.VK_RIGHT,
		KeyEvent.VK_W,KeyEvent.VK_S,KeyEvent.VK_A,KeyEvent.VK_D};
	Settings st;
	String key;
	static int keypressed = -1;


	/**
	 * @wbp.parser.constructor
	 */

	public ChangeKeys(Settings settings, String key2) {
		// TODO Auto-generated constructor stub
		this.st = settings;
		this.key = key2;	
		this.addKeyListener(this);
		this.getContentPane().setLayout(null);
		JLabel carrega = new JLabel("Carrega em qualquer tecla...");
		this.setSize(300, 100);
		carrega.setBounds(40, 20 , 200, 25);
		this.setResizable(false);
		getContentPane().add(carrega);
		this.setModal(false);
		this.setLocationRelativeTo(null);
		this.setVisible(true);
	}


	@Override
	public void keyPressed(KeyEvent e) {
		keypressed = e.getKeyCode();
		if(!equalToShootKeys(keypressed) && !equalToGameKeys(keypressed)){
			if(key.equals("up")){
				old_key[0] = new_key[0];
				new_key[0] = keypressed;
				StartMazze.getCtrls().up = keypressed;
				System.out.println(KeyEvent.getKeyText(old_key[0]) + " - " + KeyEvent.getKeyText(new_key[0]));
				this.dispose();
			}
			else
				if(key.equals("down")){
					old_key[1] = new_key[1];
					new_key[1] = keypressed;
					StartMazze.getCtrls().down = keypressed;
					System.out.println(KeyEvent.getKeyText(StartMazze.getCtrls().down));
					this.dispose();
				}
				else
					if(key.equals("left")){
						old_key[2] = new_key[2];
						new_key[2] = keypressed;
						StartMazze.getCtrls().left = keypressed;
						System.out.println(KeyEvent.getKeyText(Controls.left));
						this.dispose();
					}
					else
						if(key.equals("right")){
							old_key[3] = new_key[3];
							new_key[3] = keypressed;
							StartMazze.getCtrls().right = keypressed;
							System.out.println(KeyEvent.getKeyText(Controls.right));
							this.dispose();
						}
					else
						if(key.equals("shootup")){
							old_key[4] = new_key[4];
							new_key[4] = keypressed;
							StartMazze.getCtrls().shootUp = keypressed;
							System.out.println(KeyEvent.getKeyText(Controls.shootUp));
							this.dispose();

						}
						else 
							if(key.equals("shootdown")){
								old_key[5] = new_key[5];
								new_key[5] = keypressed;
								StartMazze.getCtrls().shootDown = keypressed;
								System.out.println(KeyEvent.getKeyText(Controls.shootDown));
								this.dispose();
							}
							else 
								if(key.equals("shootleft")){
									old_key[6] = new_key[6];
									new_key[6] = keypressed;
									StartMazze.getCtrls().shootLeft = keypressed;
									System.out.println(KeyEvent.getKeyText(Controls.shootLeft));
									this.dispose();
								}
								else
									if(key.equals("shootright")){
										old_key[7] = new_key[7];
										new_key[7] = keypressed;
										StartMazze.getCtrls().shootRight = keypressed;
										System.out.println(KeyEvent.getKeyText(Controls.shootRight));
										this.dispose();
									}
		}
		else JOptionPane.showMessageDialog(this,
				"Tecla j� em uso... escolhe outra... ","ERROR",JOptionPane.WARNING_MESSAGE);

	}

	boolean equalToShootKeys(int k){
		if(k == StartMazze.getCtrls().shootUp || k == StartMazze.getCtrls().shootDown ||k == StartMazze.getCtrls().shootLeft || k == StartMazze.getCtrls().shootRight)
			return true;
		else return false;
	}

	boolean equalToGameKeys(int k){
		if(k == StartMazze.getCtrls().up || k == StartMazze.getCtrls().down ||k == StartMazze.getCtrls().left || k == StartMazze.getCtrls().right)
			return true;
		else return false;
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}



}
