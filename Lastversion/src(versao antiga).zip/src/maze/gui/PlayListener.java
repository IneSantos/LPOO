package maze.gui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import maze.logic.Labirinto;

public class PlayListener  implements ActionListener {



	JFrame frame;
	int cenas;

	public PlayListener(JFrame frameLab)
	{
		frame = frameLab;
	}

	public PlayListener() {
	}

	public void actionPerformed(ActionEvent e) 
	{
		maze.frmLabirinto.getContentPane().removeAll();
		maze.frmLabirinto.getContentPane().setLayout(new FlowLayout());

		
			JPanel panel = new StartMazze();
			panel.setPreferredSize(new Dimension(StartMazze.TILE_DIMENSION * Labirinto.labirinto.length, StartMazze.TILE_DIMENSION * Labirinto.labirinto.length));
			maze.frmLabirinto.getContentPane().add(panel);
			panel.requestFocus();

			JPanel options = new OptionPanel(panel);
			options.setPreferredSize(new Dimension(300, StartMazze.TILE_DIMENSION * Labirinto.labirinto.length));
			maze.frmLabirinto.getContentPane().add(options);


			JOptionPane.showMessageDialog(frame,
					"Prepare yourself the adventure is about to begin.... ;) ");
			JOptionPane.showMessageDialog(frame,
					"Ok???????????????? ");
			
			maze.frmLabirinto.pack();
			maze.frmLabirinto.setVisible(true);

		
	}
}
