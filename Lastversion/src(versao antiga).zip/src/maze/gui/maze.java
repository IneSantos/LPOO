package maze.gui;

import java.awt.EventQueue;




import javax.imageio.ImageIO;
import javax.swing.JFrame;

import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.SwingConstants;

import java.awt.Color;
import java.io.IOException;
import java.awt.Panel;
import java.awt.image.BufferedImage;
public class maze extends JPanel{

	public static JFrame frmLabirinto;
	
	/**
	 * @wbp.nonvisual location=202,149
	 */
	private final Panel panel = new Panel();
	private final JButton btnNewGame = new JButton("New Game");
	private final JButton btnSettings = new JButton("Settings");
	private final JButton btnExit = new JButton("Exit");
	private final JLabel lblNewLabel = new JLabel("");
	
	private BufferedImage fundo;
	private BufferedImage titulo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmLabirinto = new JFrame();
					maze window = new maze();
					window.frmLabirinto.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public maze() {
		initialize();
	}
	public static JFrame getFrmLabirinto() {
		return frmLabirinto;
	}


	/**
	 * Initialize the contents of the frame.
	 * @throws IOException
	 */
	private void initialize(){

		
		frmLabirinto.setBackground(Color.BLACK);
	//	frmLabirinto.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Ines\\Desktop\\Lion\\tumblr_ne6w7nGTYV1rcf4rko1_500.jpg"));
		frmLabirinto.setTitle("Labirinto");
		frmLabirinto.setBounds(100, 100, 428, 282);
		//frmLabirinto.setResizable(false);
		frmLabirinto.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmLabirinto.getContentPane().setLayout(null);
		panel.setLocation(10, 150);
		panel.setSize(106, 83);
	
		try {
			fundo = ImageIO.read(this.getClass().getResource("/images/fundo2.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ImageIcon fundo = new ImageIcon("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/fundo2.jpg");
	
			
		frmLabirinto.getContentPane().add(panel);

		try {
			titulo = ImageIO.read(this.getClass().getResource("/images/How_to_Train_Your_Dragon_logo.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		ImageIcon lab = new ImageIcon("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/How_to_Train_Your_Dragon_logo.png");

		panel.setLayout(new GridLayout(0, 1, 0, 1));

		panel.add(btnNewGame);
		btnNewGame.setBounds(154, 100, 100, 23);
		btnNewGame.addActionListener(new PlayListener(frmLabirinto));

		panel.add(btnSettings);
		btnSettings.setBounds(154, 100, 100, 23);
		btnSettings.addActionListener(new SettingsListener());
		
		panel.add(btnExit);
		btnExit.setBounds(154, 100, 100, 23);
		btnExit.addActionListener(new ExitListener());
		
		JLabel labe = new JLabel(lab);
		labe.setVerticalAlignment(SwingConstants.TOP);
		//400x132
		
		labe.setBounds(120, 10, 200, 66);
		frmLabirinto.getContentPane().add(labe);
		lblNewLabel.setIcon(new ImageIcon("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/fundo2.jpg"));
		lblNewLabel.setBounds(0, 0, 414, 249);
		frmLabirinto.getContentPane().add(lblNewLabel);
				
	}

}