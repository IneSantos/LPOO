package maze.gui;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.*;
import java.io.*;

import javax.imageio.*;
import javax.swing.*;

import maze.logic.*;


public class StartMazze extends JPanel implements ActionListener, KeyListener
{
	
	
	private final int MILISSECONDS_TO_REFRESH = 50;
	public static int TILE_DIMENSION = 60;
	
	public Timer timer = new Timer(MILISSECONDS_TO_REFRESH, this);
	private BufferedImage[][] terrain;
	private int ticks = 0;
	
	private BufferedImage wall;
	private BufferedImage grass;
	private BufferedImage hero;
	private BufferedImage dragon;
	private BufferedImage dragon_sleeping;
	private BufferedImage sword;
	private BufferedImage dart;
	private BufferedImage shield;
	
	public static boolean generateMaze = false;
	
	private static Controls ctrls =  new Controls();
	
	public static Controls getCtrls() {
		return ctrls;
	}


	public StartMazze()
	{
		this.addKeyListener(this);
		this.setFocusable(true);
		setFocusTraversalKeysEnabled(false);		
		
		if(generateMaze)
			Jogo.generateLabirinto();
		else
			Jogo.standardLabirinto();
						
	
		createImages();

		timer.start();
		
		File file = new File("Jogo.ser"); 
		 ObjectInputStream in = null;

		    try {
		    	in = new ObjectInputStream(new FileInputStream(file));
		    	Jogo.obj = (Jogo) in.readObject();
		    	in.close();
		    	
		    }
		    catch (IOException except) {
		    	except.printStackTrace();
		         return;
		      }catch(ClassNotFoundException c)
		      {
		        c.printStackTrace();
		         return;
		      }
		    
	}

	
	public void createImages()
	{
		try 
		{
			wall = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/wall.png"));
			grass = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/grass.png"));
			hero = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/hero.png"));
			dragon = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/dragon.png"));
			dragon_sleeping = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/dragon_sleeping.png"));
			sword = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/sword.png"));
			dart = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/dart.png"));
			shield = ImageIO.read(new File("C:/Users/Ines/workspace/workspace java IDE/Lastversion/src/maze/gui/images/shield.png"));
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
	

	@Override
    public void paintComponent(Graphics g) 
	{
        super.paintComponent(g);
       
        for (int i = 0; i < Labirinto.labirinto.length; i++) 
        {
            for (int j = 0; j < Labirinto.labirinto.length; j++) 
            {
                int x = j * TILE_DIMENSION;
                int y = i * TILE_DIMENSION;
                BufferedImage terrainTile = null;

				int drake = Jogo.verificaDragao(j, i);
				int dartCheck = Jogo.verificaDardo(j, i);
                
                if(j == Heroi.cor.x && i == Heroi.cor.y)
					terrainTile = hero;
				else if (drake != -1)
				{
					if(Jogo.dragoes.get(drake).vivo && Jogo.dragoes.get(drake).dormir)
						terrainTile = dragon_sleeping;
					else if (Jogo.dragoes.get(drake).vivo && !Jogo.dragoes.get(drake).dormir)
						terrainTile = dragon;
					else terrainTile = grass;
				}
				else if (j == Espada.posicao.x && i == Espada.posicao.y && !Espada.recolhida)
					terrainTile = sword;
				else if (j == Escudo.posicao.x && i == Escudo.posicao.y && !Escudo.recolhida)
					terrainTile = shield;
				else if (dartCheck != -1)
					terrainTile = dart;
				else if(Labirinto.labirinto[i][j] == ' ' || Labirinto.labirinto[i][j] == 'S')
					terrainTile = grass;
				else terrainTile = wall;
                
                
                g.drawImage(terrainTile, x, y, maze.frmLabirinto);				
                
            }
        }
    }

	
	public void actionPerformed(ActionEvent a)
	{
		if(Jogo.dragonMoves != 0)
			if(ticks == 500 )
			{
				ticks = 0;
				updateDragons();
			}
			else ticks += MILISSECONDS_TO_REFRESH;

		if(Jogo.termina || !Heroi.vivo)
			System.exit(0);
		else
			repaint();
	}
	
	
	private void updateDragons() 
	{
		for(int i = 0; i < Jogo.dragoes.size(); i++)
		{
			Dragao dragao = Jogo.dragoes.get(i);
			
			if(dragao.vivo)
			{
				Jogo.moveDragao(dragao);
	
			}
			else
				Jogo.dragoes.remove(i);
		}
	}


	public void keyPressed(KeyEvent e)
	{
		int code = e.getKeyCode();
		
		updateHero(code);
	}
	
	
	public void updateHero(int code)
	{
			
		if(code == ctrls.up)
			Jogo.verificaMovimentoHeroi('w');
		else if(code == ctrls.down)
			Jogo.verificaMovimentoHeroi('s');
		else if(code == ctrls.left)
			Jogo.verificaMovimentoHeroi('a');
		else if(code == ctrls.right)
			Jogo.verificaMovimentoHeroi('d');
		else if(code == ctrls.shootUp)
			Heroi.disparaDardo('w');
		else if(code == ctrls.shootDown)
			Heroi.disparaDardo('s');
		else if(code == ctrls.shootLeft)
			Heroi.disparaDardo('a');
		else if(code == ctrls.shootRight)
			Heroi.disparaDardo('d');
		
		Jogo.verificaHeroiDragao();
	
	}


	public void keyReleased(KeyEvent e) {}
	public void keyTyped(KeyEvent e) {}
	
	


	public ActionListener restart() 
	{
		if(generateMaze)
			Jogo.generateLabirinto();
		else
			Jogo.standardLabirinto();
			
		
		terrain = new BufferedImage[Labirinto.labirinto.length][Labirinto.labirinto.length];
								
		requestFocus();
		
		return null;
	}

}
