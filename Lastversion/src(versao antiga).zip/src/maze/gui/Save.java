package maze.gui;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import maze.logic.Jogo;

public class Save {

	String filename;

	public Save(String filename){
		this.filename = filename;

		File file = new File(filename + ".ser");
		ObjectOutputStream os = null;

		try {
			os = new ObjectOutputStream(new FileOutputStream(file));
			os.writeObject(Jogo.obj);
		}
		catch (IOException except) { }
		finally { if (os != null)
			try {
				os.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}     }

	}
}
