package maze.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class OptionPanel extends JPanel implements ActionListener
{
	private JButton exit;
	private JButton newGame;
	
	
	public OptionPanel(JPanel game)
	{
		exit = new JButton("EXIT");
		exit.addActionListener(this);
		
		newGame = new JButton("NEW GAME");
		newGame.addActionListener(new RestartGame(game));
		
		
		this.add(exit);
		this.add(newGame);
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		maze.frmLabirinto.getContentPane().removeAll();
		new maze();
	
		maze.frmLabirinto.setVisible(true);

	}
}
