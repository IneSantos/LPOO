package maze.gui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class PlayListener  implements ActionListener {

	public static JPanel panel;
	public static JPanel options;
	
	int cenas; 

	public static void startGame()
	{
		Application.frmLabirinto.getContentPane().removeAll();
		Application.frmLabirinto.getContentPane().setLayout(new FlowLayout());

		JOptionPane.showMessageDialog(Application.frmLabirinto, "Prepare yourself! The adventure is about to begin! ;) ");
		JOptionPane.showMessageDialog(Application.frmLabirinto, "OK?");
		
		panel = new StartMazze();
		panel.setPreferredSize(new Dimension(Tiles.TILE_DIMENSION * Application.menu.obj.labirinto.labirinto.length, Tiles.TILE_DIMENSION * Application.menu.obj.labirinto.labirinto.length));
		Application.frmLabirinto.getContentPane().add(panel);
		panel.requestFocus();

		options = new OptionPanel(panel);
		options.setPreferredSize(new Dimension(300, Tiles.TILE_DIMENSION * Application.menu.obj.labirinto.labirinto.length));
		Application.frmLabirinto.getContentPane().add(options);

		OptionPanel.lblNewLabel = new JLabel("Dardos: "+ Integer.toString((Application.menu.obj.dardos.size())));

		

		
		Application.frmLabirinto.pack();
		Application.frmLabirinto.setVisible(true);
	}

	public void actionPerformed(ActionEvent e) 
	{
		startGame();
	}
}
