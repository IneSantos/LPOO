package maze.gui;

import java.awt.event.*;

public class Controls {
	public static int up = KeyEvent.VK_UP;
	public static int down = KeyEvent.VK_DOWN;
	public static int left = KeyEvent.VK_LEFT;
	public static int right = KeyEvent.VK_RIGHT;
	
	public static int shootUp = KeyEvent.VK_W;
	public static int shootDown = KeyEvent.VK_S;
	public static int shootLeft = KeyEvent.VK_A;
	public static int shootRight = KeyEvent.VK_D;


}
